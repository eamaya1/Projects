/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package amayaebertprojet1;

/**
 *
 * @author ebertamaya
 * 
 */
public interface BookstoreSpecification {
    
    public int restockProduct(int productId, int amount);
    public double inventoryValue();
    
}
