/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package amayaebertprojet1;

/**
 *
 * @author ebertamaya
 */
public class DVD extends Product{
     
    public DVD(String title, double price, int id){
        super(title, price, id);
    }

    
    
    
}
