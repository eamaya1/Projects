/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package amayaebertprojet1;

/**
 *
 * @author ebertamaya
 */
import java.util.ArrayList;
public class Members {
    
    private String name;
    
    public Members()
    {
        this.name = "";
    }
    
    public Members(String initName)
    {
        name = initName;
    }
    
    public String getBasName()
    {
        return name;
    }
    
    public String getPremName()
    {
        return name;
    }
}
