
package banksoftware;

import static banksoftware.CustomerDatabase.customerList;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author ebertamaya
 */
public class test {
       
    public static void main(String[] args) throws IOException {
        
        BankManager b = new BankManager();
        //String fileName = "/Users/ebertamaya/NetBeansProjects/BankSoftware/Customers/" + BankManager.customerList.get(0).getFirstName().trim() + ".txt";
        
        Customer c = new Customer("Kyle", "Lowry", 20, 2300, 43, 1234);
        BankManager.customerList.add(c);
        
        for(int i = 0; i < BankManager.customerList.size(); i++) {

            String fileName = "/Users/ebertamaya/NetBeansProjects/BankSoftware/Customers/" + BankManager.customerList.get(0).getFirstName().trim() + ".txt";
            File file = new File("/Users/ebertamaya/NetBeansProjects/BankSoftware/Customers/", fileName);
            
            String fileContents = "";
            
            fileContents += BankManager.customerList.get(i).getFirstName() + "\n";
            fileContents += BankManager.customerList.get(i).getLastName() + "\n";
            fileContents += BankManager.customerList.get(i).getAge() + "\n";
            fileContents += BankManager.customerList.get(i).getCredit() + "\n";
            fileContents += BankManager.customerList.get(i).getAccountBalance() + "\n";
            fileContents += BankManager.customerList.get(i).getPin();
            
            
            if(file.exists()) {
                file.delete();
            }        
            
            FileWriter writer = new FileWriter(fileName);
            
            writer.write(fileContents);
            writer.close();
        }
                
        
    }

}
