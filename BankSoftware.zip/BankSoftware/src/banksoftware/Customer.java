package banksoftware;

/**
 *
 * @author ebertamaya
 */
public class Customer extends Person {    
    private int credit;
//    private double accountBalance;
    private int fourDigitPin;
    private double savingsBalance;
    private double checkingsBalance;
    
    
    public Customer(String fName, String lName, int a, int cred, int fDP, double sB, double cB) { //, double aB
        super(fName, lName, a);
        this.credit = cred;
//        this.accountBalance = aB;
        this.fourDigitPin = fDP;
        this.savingsBalance = sB;
        this.checkingsBalance = cB;
    }

    public int getCredit() {
        return credit;
    }

//    public double getAccountBalance() {
//        return accountBalance;
//    }
    
    public void withdrawSavings(double withdrawAmount) {
        savingsBalance -= withdrawAmount;
    } 
    
    public void withdrawCheckings(double withdrawAmount) {
        checkingsBalance -= withdrawAmount;
    }
    
    public void depositSavings(double depositAmount) {
        savingsBalance += depositAmount;
    }
    
    public void depositCheckings(double depositAmount) {
        checkingsBalance += depositAmount;
    }
    
    public int getPin() {
        return fourDigitPin;
    }

    public double getSavingsBalance() {
        return savingsBalance;
    }

    public double getCheckingsBalance() {
        return checkingsBalance;
    }

    @Override
    public String toString() {
        return "First Name: " + this.getFirstName() + "\n" +
                "Last Name: " + this.getLastName();
                
    }


}
