package banksoftware;

/**
 *
 * @author ebertamaya
 */
public class Customer extends Person {
    
    private int credit;
    private int accountBalance;
    private int fourDigitPin;
    
    
    public Customer(String fName, String lName, int a, int cred, int aB, int fDP) {
        super(fName, lName, a);
        this.credit = cred;
        this.accountBalance = aB;
        this.fourDigitPin = fDP;
    }

    public int getCredit() {
        return credit;
    }

    public int getAccountBalance() {
        return accountBalance;
    }
    
    public void withDraw(int withDrawAmount) {
        accountBalance = accountBalance - withDrawAmount;
    } 
    
    public int getPin() {
        return fourDigitPin;
    }
    
    public String toString() {
        return "First Name: " + this.getFirstName() + "\n" +
                "Last Name: " + this.getLastName() + "\n" +
                "Age: "  + this.getAge() + "\n" +
                "Credit: " + this.credit + "\n" + 
                "Balance: " + this.accountBalance + "\n";
                
    }
}
