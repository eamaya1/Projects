package banksoftware;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author ebertamaya
 */
public class BankSoftware {

    public static void main(String[] args) {        

        BankManager bank = new BankManager();
        Scanner sc = new Scanner(System.in);
        boolean menuExit = false;
        
        
        while(!menuExit) {
            System.out.println("Welcome to your personalized Bank Software Tool!");
            System.out.println("Please enter a number for the list of options below.");
            System.out.println("[1] Add Customer");
            System.out.println("[2] Display Customer Details");
            System.out.println("[3] Exit");
            
            int userChoice = sc.nextInt();
            
            switch(userChoice) {
                case 1:
                {
                    try {
                        bank.AddCustomer();                    
                    } catch (IOException ex) {
                        Logger.getLogger(BankSoftware.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }                   
                    break;
                case 2:
                    bank.DisplayCustomerDetails();
                    break;
                case 3:
                    System.out.println("Thank you for banking with us!");
                    menuExit = true;
            }
                    
        }

        
    }
}



























//        File dir = new File("/Users/ebertamaya/NetBeansProjects/BankSoftware/Customers");
//        
//        File[] listFiles = dir.listFiles();
//        
//        String fileName = listFiles[0].getPath();
//        
//        System.out.println(fileName);

//        BankManager bankManager = new BankManager();
//        
//        System.out.println(bankManager.getCustomers().get(0));
        


//                    System.out.println("Which Customer are you?");
//                    
//                    for(int i = 0; i < BankManager.customerList.size(); i++) { 
//                        System.out.println("[" + i + "]" + BankManager.customerList.get(i).toString());
//                    }
//                    
//                    int customerChoice = sc.nextInt();
//                    int enterPin; 
//                    System.out.println("Welcome " + BankManager.customerList.get(customerChoice).getFirstName());
//                    
