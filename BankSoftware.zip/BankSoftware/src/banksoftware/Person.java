package banksoftware;

/**
 *
 * @author ebertamaya
 */
public class Person {
    
    private String firstName;
    private String lastName;
    private int age;
    
    
    public Person(String fName, String lName, int a) {
        this.firstName = fName;
        this.lastName = lName;
        this.age = a;       
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setAge(int age) {
        this.age = age;
    }
    
    
}


