package banksoftware;
import java.util.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author ebertamaya
 */
public class CustomerDatabase {   
 
    public static ArrayList<Customer> customerList;    
    private static String pathToFiles;
    private static String pathToCustomers;

    
    /**
     * Loads customers from directory. 
     */
    public static void LoadDatabase() {
        pathToFiles = System.getProperty("user.dir");  //"/Users/ebertamaya/NetBeansProjects/BankSoftware/"; //This should work on all systems...If not the directory can be added manually here.
        pathToCustomers = pathToFiles + "/Customers/";
        
        try{
            LoadCustomers();
        } catch(FileNotFoundException ex) {
            System.out.println("Problem, file does not exist");
        } catch(IOException ex) {
            System.out.println("Error Message");
        }
    }
    
    /**
     * 
     * @throws IOException 
     */
    private static void LoadCustomers() throws IOException {
        customerList = new ArrayList<Customer>();
        File dir = new File(pathToCustomers);  //"/Users/ebertamaya/NetBeansProjects/BankSoftware/Customers");
        File[] listFiles = dir.listFiles();
        
        String[] fileNames = new String[listFiles.length];
        
        for(int i = 0; i < listFiles.length; i++) { //Getting File Paths from Files into Strings
            fileNames[i] = listFiles[i].getPath();
        }
        
        for(int i = 0; i < listFiles.length; i++) {
            if(fileNames[i].equals(System.getProperty("user.dir") + "/Customers/.DS_Store")) { //"/Users/ebertamaya/NetBeansProjects/BankSoftware/Customers/.DS_Store")) {
                continue;
            }
            customerList.add(CreateCustomerFromTextFile(fileNames[i]));
        }
        
        sortCustomersByLastName();
    }
    
    
    private static Customer CreateCustomerFromTextFile(String pathAndFileName) throws IOException {
        
        Path path = Paths.get(pathAndFileName);
        List<String> lines = Files.readAllLines(path);
        
        String firstName = lines.get(0); //First Name Line
        String lastName = lines.get(1); //Last Name Line
        int age = Integer.parseInt(lines.get(2)); //Age Line
        int credit = Integer.parseInt(lines.get(3)); //Credit Line
//        double accountBalance = Double.parseDouble(lines.get(4)); //Account Balance Line
        int pin = Integer.parseInt(lines.get(4)); //Pin Line
        double savingsBalance = Double.parseDouble(lines.get(5));
        double checkingsBalance = Double.parseDouble(lines.get(6));
        
        return new Customer(firstName, lastName, age, credit, pin, savingsBalance, checkingsBalance); //accountBalance,
    }
    
    public static void writeCustomersToFiles() throws IOException {
        
        for(int i = 0; i < customerList.size(); i++) {
            
            //This Line
            String fileName = pathToCustomers + customerList.get(i).getFirstName().trim() + ".txt";
            File file = new File(pathToCustomers, fileName);
            
            String fileContents = "";
            
            fileContents += customerList.get(i).getFirstName() + "\n";
            fileContents += customerList.get(i).getLastName() + "\n";
            fileContents += customerList.get(i).getAge() + "\n";
            fileContents += customerList.get(i).getCredit() + "\n";
//            fileContents += customerList.get(i).getAccountBalance() + "\n";
            fileContents += customerList.get(i).getPin() + "\n";        
            fileContents += customerList.get(i).getSavingsBalance() + "\n";
            fileContents += customerList.get(i).getCheckingsBalance() + "\n";
            
            if(file.exists()) {
                file.delete();
            }        
            
            FileWriter writer = new FileWriter(fileName);
            
            writer.write(fileContents);
            writer.close();
        }
    }
    
    public static void sortCustomersByLastName() {
        
        int n = customerList.size();
        
        for(int i = 0; i < n - 1; i++) {
            int minIndex = i;
            
            for(int j = i+1; j < n; j++) {
                if(customerList.get(j).getLastName().compareTo(customerList.get(minIndex).getLastName()) < 0) {
                    minIndex = j;
                }
            }
            
            Customer temp = customerList.get(minIndex);
            customerList.set(minIndex, customerList.get(i));
            customerList.set(i, temp);
        }


    }
}
