package banksoftware;
import java.util.*;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 *
 * @author ebertamaya
 */
public class CustomerDatabase {
    
    public static ArrayList<Customer> customerList;    
    private static String pathToFiles;
    private static String pathToCustomers;

    
    public static void LoadDatabase() {
        pathToFiles = "/Users/ebertamaya/NetBeansProjects/BankSoftware/";
        pathToCustomers = pathToFiles + "Customers/";
        
        try{
            LoadCustomers();
        } catch(FileNotFoundException ex) {
            System.out.println("Problem, file does not exist");
        } catch(IOException ex) {
            System.out.println("Error Message");
        }
    }
    
    
    private static void LoadCustomers() throws IOException {
        customerList = new ArrayList<Customer>();
        File dir = new File(pathToCustomers);  //"/Users/ebertamaya/NetBeansProjects/BankSoftware/Customers");
        File[] listFiles = dir.listFiles();
        
        String[] fileNames = new String[listFiles.length];
        
        for(int i = 0; i < listFiles.length; i++) { //Getting File Paths from Files into Strings
            fileNames[i] = listFiles[i].getPath();
        }
        
        for(int i = 0; i < listFiles.length; i++) {
            if(fileNames[i].equals("/Users/ebertamaya/NetBeansProjects/BankSoftware/Customers/.DS_Store")) {
                continue;
            }
            customerList.add(CreateCustomerFromTextFile(fileNames[i]));
        }
  
    }
    
    
    private static Customer CreateCustomerFromTextFile(String pathAndFileName) throws IOException {
        
        Path path = Paths.get(pathAndFileName);
        List<String> lines = Files.readAllLines(path);
        
        String firstName = lines.get(0); //First Name Line
        String lastName = lines.get(1); //Last Name Line
        int age = Integer.parseInt(lines.get(2)); //Age Line
        int credit = Integer.parseInt(lines.get(3)); //Credit Line
        int accountBalance = Integer.parseInt(lines.get(4)); //Account Balance Line
        int pin = Integer.parseInt(lines.get(5));
        
        return new Customer(firstName, lastName, age, credit, accountBalance, pin);
    }
    
    public static void writeCustomersToFiles() throws IOException {
        
        for(int i = 0; i < customerList.size(); i++) {
            
            //This Line
            String fileName = pathToCustomers + customerList.get(i).getFirstName().trim() + ".txt";
            File file = new File(pathToCustomers, fileName);
            
            String fileContents = "";
            
            fileContents += customerList.get(i).getFirstName() + "\n";
            fileContents += customerList.get(i).getLastName() + "\n";
            fileContents += customerList.get(i).getAge() + "\n";
            fileContents += customerList.get(i).getCredit() + "\n";
            fileContents += customerList.get(i).getAccountBalance() + "\n";
            fileContents += customerList.get(i).getPin();            
            
            if(file.exists()) {
                file.delete();
            }        
            
            FileWriter writer = new FileWriter(fileName);
            
            writer.write(fileContents);
            writer.close();
        }
    }
    
}
