package banksoftware;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ebertamaya
 */
public class BankManager extends CustomerDatabase{
       
    public BankManager() {
        CustomerDatabase.LoadDatabase();
    }
    
    public ArrayList<Customer> getCustomers() {
        return CustomerDatabase.customerList;
    }
    
    public void AddCustomer() throws IOException {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Please enter your First Name");
        String fName = sc.next();
        System.out.println("Please enter your Last Name");
        String lName = sc.next();
        System.out.println("Please enter your age");
        int age = sc.nextInt();
        System.out.println("Please enter your credit");
        int credit = sc.nextInt();
        System.out.println("Please enter your initial deposit");
        int balance = sc.nextInt();
        System.out.println("Please enter your 4 digit PIN"); 
        int pin = sc.nextInt();

        Customer newCustomer = new Customer(fName, lName, age, credit, balance, pin);
        BankManager.customerList.add(newCustomer);
        BankManager.writeCustomersToFiles();
              
    }
    
    public void DisplayCustomerDetails() {
        Scanner sc = new Scanner(System.in);
        
        boolean customerExit = false;
        System.out.println("Which Customer are you?");
                    
        for(int i = 0; i < BankManager.customerList.size(); i++) { //Displays Customers
            System.out.println("[" + i + "]" + BankManager.customerList.get(i).toString());
        }
                    
        int customerChoice = sc.nextInt(); //Customer chooses
        
        System.out.println("Enter pin for " + BankManager.customerList.get(customerChoice).getFirstName()); //Enter Pin for them        
        int enterPin = sc.nextInt(); 
        
        if(enterPin == BankManager.customerList.get(customerChoice).getPin()) { //Account Access Granted, Functionalities Given
            while(!customerExit) {
                System.out.println("Welcome " + BankManager.customerList.get(customerChoice).getFirstName());

                System.out.println("Enter number based on option");
                System.out.println("[1] Display Balance");
                System.out.println("[2] Withdraw");
                System.out.println("[3] Exit");

                int customerFunction = sc.nextInt();
                switch(customerFunction) {
                    case 1: 
                        System.out.println("Your Balance is: " + BankManager.customerList.get(customerChoice).getAccountBalance());
                        break;
                    case 2:
                        System.out.println("How much would you like to withdraw?");
                        int withdrawAmount = sc.nextInt();

                        BankManager.customerList.get(customerChoice).withDraw(withdrawAmount);
                        System.out.println("Your new balance is " + BankManager.customerList.get(customerChoice).getAccountBalance());
                    {
                        try {
                            BankManager.writeCustomersToFiles();
                        } catch (IOException ex) {
                            System.out.println("Error, IOException Found");
                        }
                    }
                        break;

                    case 3:
                        System.out.println("Goodbye, " + BankManager.customerList.get(customerChoice).getFirstName());
                        customerExit = true;
                        break;
                }
            }
        }             
    }
    
}
