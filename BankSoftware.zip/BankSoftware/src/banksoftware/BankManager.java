package banksoftware;
import java.io.IOException;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ebertamaya
 */
public class BankManager extends CustomerDatabase {
       
    
    public BankManager()  {
        CustomerDatabase.LoadDatabase();
    }
    
    public ArrayList<Customer> getCustomers() {
        return CustomerDatabase.customerList;
    }
    
    public void AddCustomer() {
        
        Scanner sc = new Scanner(System.in);
        boolean validInput = false;
        try {
            System.out.println("Please enter your First Name");
            String fName = sc.nextLine();
            
            if(!fName.matches("[a-zA-Z]+")) {
                throw new InputMismatchException();
            }  
            
            System.out.println("Please enter your Last Name");
            String lName = sc.nextLine();
           
            if(!lName.matches("[a-zA-Z]+")) {
                throw new InputMismatchException();
            }                   
           
            System.out.println("Please enter your age");
            int age = sc.nextInt();
            System.out.println("Please enter your credit");
            int credit = sc.nextInt();
//            System.out.println("Please enter your initial deposit");
//            double balance = sc.nextDouble();
            System.out.println("Please enter your 4 digit PIN"); 
            int pin = sc.nextInt();
            System.out.println("Please enter your initial savings deposit");
            double savingDeposit = sc.nextDouble();
            System.out.println("Please enter your initial checkings deposit");
            double checkingDeposit = sc.nextDouble();
            
            Customer newCustomer = new Customer(fName, lName, age, credit, pin, savingDeposit, checkingDeposit); //balance
            BankManager.customerList.add(newCustomer);
            BankManager.writeCustomersToFiles();
        } catch(InputMismatchException ex) {
            System.out.println("Please enter a valid detail.");
        } catch(IOException ex) {
            System.out.println("IO Exception.");
        }
                
//
//        Customer newCustomer = new Customer(fName, lName, age, credit, balance, pin);
//        BankManager.customerList.add(newCustomer);
//        BankManager.writeCustomersToFiles();
//              
    }
    
    public void DisplayCustomerDetails() throws IOException, InterruptedException {
        Scanner sc = new Scanner(System.in);
        
        boolean customerExit = false;
        System.out.println("Which Customer are you?" + "\n");
        Thread.sleep(1000);
                    
        for(int i = 0; i < BankManager.customerList.size(); i++) { //Displays Customers
            System.out.println("[" + i + "]" + "\n" + BankManager.customerList.get(i).toString());            
        }      
        System.out.println("Or enter -1 to return to menu.");  
        
        int customerChoice = sc.nextInt(); //Customer chooses

        if(customerChoice == -1 || customerChoice > customerList.size()) { //Exiting the program
            return;
        }
        
        System.out.println("Enter pin for " + BankManager.customerList.get(customerChoice).getFirstName()); //Enter Pin for them        
        int enterPin = sc.nextInt(); 
        
        if(enterPin == BankManager.customerList.get(customerChoice).getPin()) { //Account Access Granted, Functionalities Given
            while(!customerExit) {
                System.out.println("Welcome " + BankManager.customerList.get(customerChoice).getFirstName());

                System.out.println("Enter number based on option");
                System.out.println("[1] Display Balance");
                System.out.println("[2] Withdraw");
                System.out.println("[3] Deposit");
                System.out.println("[4] Check Credit Score");
                System.out.println("[5] Exit");

                int customerFunction = sc.nextInt();
                switch(customerFunction) {
                    case 1:  //Display Balance F
                        System.out.println("Your Savings Balance is: $" + BankManager.customerList.get(customerChoice).getSavingsBalance());
                        System.out.println("Your Checkings Balance is: $" + BankManager.customerList.get(customerChoice).getCheckingsBalance());

                        break;
                        
                    case 2: //Withdraw (Savings/Checkings)
                        
                        System.out.println("Would you like to withdraw from savings or checkings? Enter 'S' or 'C' respectively.");
                        
                        String accountChoice = sc.next();
                        accountChoice = accountChoice.toLowerCase();
                        
                        if(accountChoice.equals("s")) {
                            System.out.println("How much would you like to withdraw?");
                            double withdrawAmount = sc.nextDouble();

                            BankManager.customerList.get(customerChoice).withdrawSavings(withdrawAmount);
                            System.out.println("Your new balance is $" + BankManager.customerList.get(customerChoice).getSavingsBalance());

                            BankManager.writeCustomersToFiles();

                            break;
                        }
                        
                        else if (accountChoice.equals("c")) {
                            System.out.println("How much would you like to withdraw?");
                            double withdrawAmount = sc.nextDouble();

                            BankManager.customerList.get(customerChoice).withdrawCheckings(withdrawAmount);
                            System.out.println("Your new balance is $" + BankManager.customerList.get(customerChoice).getCheckingsBalance());

                            BankManager.writeCustomersToFiles();

                            break;
                        }
                        
//                        System.out.println("How much would you like to withdraw?");
//                        double withdrawAmount = sc.nextDouble();
//
//                        BankManager.customerList.get(customerChoice).withdraw(withdrawAmount);
//                        System.out.println("Your new balance is $" + BankManager.customerList.get(customerChoice).getAccountBalance());
//                    
//                        BankManager.writeCustomersToFiles();
//
//                        break;
                        
                    case 3: //Deposit (Savings/Checkings)
                        
                        System.out.println("Would you like to deposit from savings or checkings? Enter 'S' or 'C' respectively.");
                        
                        accountChoice = sc.next();
                        accountChoice = accountChoice.toLowerCase();
                        
                        if(accountChoice.equals("s")) {
                            System.out.println("How much are you depositing today?");
                            double deposit = sc.nextDouble();

                            BankManager.customerList.get(customerChoice).depositSavings(deposit);
                            System.out.println("Your new balance is $" + BankManager.customerList.get(customerChoice).getSavingsBalance());

                            BankManager.writeCustomersToFiles();
                 
                            break;
                        }
                        
                        else if(accountChoice.equals("c")) {
                            System.out.println("How much are you depositing today?");
                            double deposit = sc.nextDouble();

                            BankManager.customerList.get(customerChoice).depositCheckings(deposit);
                            System.out.println("Your new balance is $" + BankManager.customerList.get(customerChoice).getCheckingsBalance());

                            BankManager.writeCustomersToFiles();
                            
                            break;
                        }                      
//                        System.out.println("How much are you depositing today?");
//                        double deposit = sc.nextDouble();
//                        
//                        BankManager.customerList.get(customerChoice).deposit(deposit);
//                        System.out.println("Your new balance is $" + BankManager.customerList.get(customerChoice).getAccountBalance());
//                        
//                        BankManager.writeCustomersToFiles();
                    case 4:
                        System.out.println("Hello, " + BankManager.customerList.get(customerChoice).getFirstName());
                        int custCredScore = BankManager.customerList.get(customerChoice).getCredit();
                        
                        if(custCredScore > 300 && custCredScore < 629) {
                            System.out.println("Your Credit Score is " + custCredScore + ": Poor");
                        } else if(custCredScore > 630 && custCredScore < 689) {
                            System.out.println("Your Credit Score is " + custCredScore + ": Fair");
                        } else if(custCredScore > 690 && custCredScore < 719) {
                            System.out.println("Your Credit Score is " + custCredScore + ": Good");
                        } else if(custCredScore > 720 && custCredScore < 850) {
                            System.out.println("Your Credit Score is " + custCredScore + ": Great");
                        } else {
                            System.out.println("Unable to retrieve details, please contact bank.");
                        }
                        
                        Thread.sleep(3000);
                        break;
                        
                    case 5: //Exiting Account.
                        System.out.println("Goodbye, " + BankManager.customerList.get(customerChoice).getFirstName());
                        customerExit = true;
                        break;
                }
            }
        } else {
            System.out.println("Incorrect PIN entered, access denied.");
        }             
    }
    
}
